The current Campus Care application is intentionally kept in the root `index.html` so its existing single-file UI and JavaScript remain unchanged.
