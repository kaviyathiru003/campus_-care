# CAMPUS CARE 🎓

Campus Care is a student support portal packaged as a GitHub/npm-ready Vite project.

## Included features

- Student / Guest / Admin login flow
- Firebase Realtime Database integration hooks
- Campus complaints and status tracking
- Admin dashboard
- Heatmap view
- Government grants section
- Staff task app
- Camera proof / Vision AI UI
- English + Tamil voice input UI
- Campus Copilot chat UI
- Food complaint section
- Leaderboard
- Dark / Light mode
- Settings and logout

## Run locally

```bash
npm install
npm run dev
```

Then open the local Vite URL shown in the terminal.

## Production build

```bash
npm run build
npm run preview
```

## GitHub

Create a GitHub repository, then:

```bash
git init
git add .
git commit -m "Initial Campus Care project"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

## Firebase

The supplied HTML already contains Firebase Realtime Database initialization and placeholder web-app configuration. Replace the placeholder Firebase Web App configuration in `index.html` with your own project configuration before enabling the shared database.

Never put Firebase Admin SDK credentials, service-account JSON files, private keys, or other server credentials in this repository.

## Important asset

The original HTML references a logo image named:

`WhatsApp Image 2026-10-05 at 4.41.29 PM (1).jpeg`

Place that image in the project root if you want the original logo to appear. The image was not included in the uploaded HTML file itself.
